export const environment = {
	"projectId": "demo-project",
	"appId": "1:61579563264:web:ca0d7aae107df5efc8a3e5",
	"storageBucket": "prestige-ape-test.firebasestorage.app",
	"apiKey": "AIzaSyBZMVwp0SgIJ0C5JCO1Ll9ZYLd9VAEzX20",
	"authDomain": "prestige-ape-test.firebaseapp.com",
	"messagingSenderId": "61579563264",
  "firestoreUseLocal": true,
  "firebaseStorageUseLocal": true,
  "firebaseAuthUseLocal": true,
  "authRequired": false,
  "authorizedUids": [
    "OVurK9ebeGer5oa0IsrzhW3fy3aE",
  ],
};
