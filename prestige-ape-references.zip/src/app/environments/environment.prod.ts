export const environment = {
	"projectId": "prestige-ape-test",
	"appId": "1:61579563264:web:ca0d7aae107df5efc8a3e5",
	"storageBucket": "prestige-ape-test.firebasestorage.app",
	"apiKey": "AIzaSyBZMVwp0SgIJ0C5JCO1Ll9ZYLd9VAEzX20",
	"authDomain": "prestige-ape-test.firebaseapp.com",
	"messagingSenderId": "61579563264",
  "firestoreUseLocal": false,
  "firebaseStorageUseLocal": false,
  "firebaseAuthUseLocal": false,
  "authRequired": true,
  "databaseId": "test-references",
  "authorizedUids": [
    "PmGRjYhJqwN6W6GV1JaaldRF4Xi2",
  ],
};
